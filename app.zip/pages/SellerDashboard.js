export default function SellerDashboard() {
    return `<h1>Seller Dashboard</h1>`;
}