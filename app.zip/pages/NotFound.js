import View from './../scripts/view.js';

export default class NotFound extends View {
    template() {
        return`<h1> Not Found - 404</h1>`
    }
    
}