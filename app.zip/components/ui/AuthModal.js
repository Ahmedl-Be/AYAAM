
import View from "../../scripts/view.js";
import SignupForm from "../auth/SignupForm.js";



export default class AuthModal extends View {
    template() {
        const mode = this.params.mode;
    return `
      <div class="modal fade show d-block" tabindex="-1" id= "auth-modal">
        <div class="modal-dialog">
          <div class="modal-content">
     
             <!-- HEADER -->
            <div class="modal-header">
              <h5 class="modal-title" id="authModalLabel">${mode === "signup" ? "Sign Up" : "Login"}</h5>
              <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
        
            <div class="modal-body" id='auth-wrapper'></div>

            <div class="modal-footer">
              <small id="toggleAuth" class="text-primary" style="cursor:pointer">
                ${mode === 'signup'? ' Already have an account? Login' : 'Dont have account? Join us'}
              </small>
          </div>
        </div>
      </div>
    `;
  }

  script() {
    document.getElementById("closeModal").addEventListener("click", () => {
      location.hash = "#/home"; 
    });

    this.subview(SignupForm,{parent: 'auth-wrapper', title: 'Sign Up'}, {mode: "signup"})
  }
}