/**
 * Admin Utilities: utility functions used across admin modules
 */

// /**
//  * Check if user has admin permissions
//  * @param {Object} user - User object
//  * @returns {boolean} - True if user is admin
//  */
// export function isAdmin(user) {
//     return user && (user.role === 'Admin' || user.role === 'admin');
// }

// /**
//  * Check if user has seller permissions
//  * @param {Object} user - User object
//  * @returns {boolean} - True if user is seller
//  */
// export function isSeller(user) {
//     return user && (user.role === 'Seller' || user.role === 'seller');
// }

