export function emptyItems() {
    return `
    <p class="text-muted" > No items available.</p>
    `
}